from __future__ import annotations

from dataclasses import dataclass

from app.models import CheckerSummary, GraphResult, Meta, stable_version, utc_now_iso
from app.storage.neo4j_store import Neo4jStore
from app.storage.redis_store import RedisStore
from app.tools import checker, extract, merge, retrieval
from app.tools.seed_corpus import Passage


@dataclass
class Orchestrator:
    redis_store: RedisStore
    neo4j_store: Neo4jStore

    async def generate_graph(self, *, job_id: str, concept: str, domains: list[str] | None, depth: int, strict_check: bool) -> GraphResult:
        await self.redis_store.set_status(job_id, status="running", progress=5, message="Planning")
        await self.redis_store.log(job_id, f"[Planner] concept={concept} depth={depth}")

        selected_domains = retrieval.domains_or_default(domains)
        await self.redis_store.log(job_id, f"[Planner] domains={selected_domains}")
        await self.redis_store.set_status(job_id, status="running", progress=10, message="Retrieving")

        passages_by_domain: dict[str, list[Passage]] = {}
        for i, d in enumerate(selected_domains):
            ps = await retrieval.search(d, concept)
            passages_by_domain[d] = ps
            await self.redis_store.log(job_id, f"[Retrieve] {d}: {len(ps)} passages")
            await self.redis_store.set_status(job_id, status="running", progress=min(30, 10 + (i + 1) * 4), message="Retrieving")

        passages = retrieval.flatten(passages_by_domain)
        await self.redis_store.set_status(job_id, status="running", progress=35, message="Extracting")

        ex = extract.graph_from_passages(concept, passages)
        await self.redis_store.log(job_id, f"[Extract] nodes={len(ex.nodes)} edges={len(ex.edges)}")

        await self.redis_store.set_status(job_id, status="running", progress=50, message="Bridge discovery")
        ex2 = extract.bridge_discovery(ex)
        await self.redis_store.log(job_id, f"[Bridge] nodes={len(ex2.nodes)} edges={len(ex2.edges)}")

        await self.redis_store.set_status(job_id, status="running", progress=65, message="Merge & de-dup")
        merged_nodes, merged_edges = merge.merge_synonyms(ex2.nodes, ex2.edges)
        await self.redis_store.log(job_id, f"[Merge] nodes={len(merged_nodes)} edges={len(merged_edges)}")

        graph = GraphResult(
            concept=concept,
            nodes=merged_nodes,
            edges=merged_edges,
            meta=Meta(
                generated_at=utc_now_iso(),
                version=stable_version(),
                checker_summary=CheckerSummary(),
            ),
        )

        await self.redis_store.set_status(job_id, status="running", progress=75, message="Checking")
        graph = checker.run_check(graph, strict=strict_check)
        await self.redis_store.log(
            job_id,
            f"[Check] passed={graph.meta.checker_summary.passed} failed={graph.meta.checker_summary.failed}",
        )

        await self.redis_store.set_status(job_id, status="running", progress=85, message="Persisting")
        await self.neo4j_store.upsert_graph(graph)
        await self.redis_store.log(job_id, "[Persist] upserted into Neo4j")

        await self.redis_store.set_result(job_id, graph)
        await self.redis_store.set_status(job_id, status="succeeded", progress=100, message="Done")
        return graph

