from __future__ import annotations

import re
from typing import Iterable

import httpx
from urllib.parse import quote

from app.config import settings
from app.tools.seed_corpus import DEFAULT_DOMAINS, Passage, SEED_PASSAGES


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip().lower())


async def search(domain: str, concept: str) -> list[Passage]:
    """
    Retrieval tool.
    - Default: offline seed corpus (guaranteed to work)
    - Optional: Wikipedia REST search (ENABLE_WIKI=1)
    """
    concept_n = _norm(concept)
    out: list[Passage] = []

    for p in SEED_PASSAGES.get(domain, []):
        if concept_n in _norm(p.snippet) or concept_n in _norm(p.title) or concept_n in _norm(domain):
            out.append(p)
    if out:
        return out

    # If the concept isn't found, still return a domain-specific generic passage for robustness
    if SEED_PASSAGES.get(domain):
        return SEED_PASSAGES[domain][:1]

    if not settings.enable_wiki:
        return []

    # Optional online retrieval
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            safe = quote(concept.strip())
            r = await client.get("https://en.wikipedia.org/api/rest_v1/page/summary/" + safe)
            if r.status_code >= 400:
                return []
            data = r.json()
            extract = (data.get("extract") or "").strip()
            if not extract:
                return []
            return [
                Passage(
                    domain=domain,
                    title=str(data.get("title") or concept),
                    snippet=extract[:500],
                    url=str((data.get("content_urls") or {}).get("desktop", {}).get("page") or ""),
                )
            ]
    except Exception:
        return []


def domains_or_default(domains: list[str] | None) -> list[str]:
    if not domains:
        return DEFAULT_DOMAINS
    return domains


def flatten(passages_by_domain: dict[str, list[Passage]]) -> list[Passage]:
    out: list[Passage] = []
    for _, ps in passages_by_domain.items():
        out.extend(ps)
    return out

