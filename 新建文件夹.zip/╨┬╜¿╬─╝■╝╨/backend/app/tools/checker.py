from __future__ import annotations

from app.models import Edge, GraphResult


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def evidence_check(edge: Edge) -> tuple[bool, float]:
    """
    Very lightweight "check layer" for offline demo:
    - evidence snippet must be non-empty
    - explanation and snippet should share at least one keyword token
    """
    sn = (edge.evidence.snippet or "").strip()
    if not sn:
        return False, 0.0

    exp = (edge.explanation or "").lower()
    tokens = {t for t in sn.lower().replace("-", " ").split() if len(t) >= 6}
    if not tokens:
        return True, 0.6

    overlap = sum(1 for t in list(tokens)[:12] if t in exp)
    score = _clamp01(0.4 + 0.08 * overlap)
    return (score >= 0.5), score


def run_check(graph: GraphResult, strict: bool = True) -> GraphResult:
    passed = 0
    failed = 0
    edges: list[Edge] = []

    for e in graph.edges:
        ok, score = evidence_check(e)
        if ok:
            passed += 1
            e.checked = True
            e.confidence = _clamp01((e.confidence + score) / 2)
        else:
            failed += 1
            e.checked = False
            e.confidence = _clamp01(e.confidence * 0.45)
            if strict:
                e.explanation = e.explanation or "No supported evidence found; marked as unchecked."
        edges.append(e)

    graph.edges = edges
    graph.meta.checker_summary.passed = passed
    graph.meta.checker_summary.failed = failed
    return graph

