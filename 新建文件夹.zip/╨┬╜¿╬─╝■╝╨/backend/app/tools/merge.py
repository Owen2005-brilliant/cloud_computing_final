from __future__ import annotations

import re

from app.models import Edge, Node


def _k(name: str, domain: str) -> str:
    s = re.sub(r"\s+", " ", name.strip().lower())
    return f"{domain.lower()}::{s}"


def merge_synonyms(nodes: list[Node], edges: list[Edge]) -> tuple[list[Node], list[Edge]]:
    """
    Very light de-dup:
    - merge nodes by (domain, normalized name)
    - rewrite edges to merged node ids
    """
    id_map: dict[str, str] = {}
    kept: dict[str, Node] = {}

    for n in nodes:
        key = _k(n.name, n.domain)
        if key not in kept:
            kept[key] = n
        id_map[n.id] = kept[key].id

    out_edges: dict[tuple[str, str, str], Edge] = {}
    for e in edges:
        s = id_map.get(e.source, e.source)
        t = id_map.get(e.target, e.target)
        k = (s, t, e.relation)
        if k not in out_edges or out_edges[k].confidence < e.confidence:
            e.source = s
            e.target = t
            out_edges[k] = e

    return list(kept.values()), list(out_edges.values())

