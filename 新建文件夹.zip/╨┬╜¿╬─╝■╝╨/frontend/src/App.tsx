import React from "react";
import { expandNode, generateGraph, getGraph, getJob, type GraphResult, type JobStatus, type Node } from "./api";
import { GraphView } from "./components/GraphView";

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export function App() {
  const [concept, setConcept] = React.useState("Entropy");
  const [job, setJob] = React.useState<JobStatus | null>(null);
  const [graph, setGraph] = React.useState<GraphResult | null>(null);
  const [selectedNode, setSelectedNode] = React.useState<Node | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);

  const pickNode = React.useCallback(
    (nodeId: string) => {
      const n = graph?.nodes.find((x) => x.id === nodeId) || null;
      setSelectedNode(n);
    },
    [graph]
  );

  async function pollJob(jobId: string) {
    for (let i = 0; i < 120; i++) {
      const j = await getJob(jobId);
      setJob(j);
      if (j.status === "succeeded") {
        // Load from Neo4j so UI matches persisted view
        const g = await getGraph(j.concept, 2);
        setGraph(g);
        setSelectedNode(null);
        return;
      }
      if (j.status === "failed") return;
      await sleep(800);
    }
  }

  async function onGenerate() {
    setError(null);
    setBusy(true);
    setGraph(null);
    setSelectedNode(null);
    try {
      const r = await generateGraph({ concept, depth: 2, strict_check: true });
      await pollJob(r.job_id);
    } catch (e: any) {
      setError(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  }

  async function onExpand() {
    if (!selectedNode) return;
    setError(null);
    setBusy(true);
    try {
      const g = await expandNode(selectedNode.id, 1);
      setGraph(g);
      setSelectedNode(null);
    } catch (e: any) {
      setError(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="container">
      <div className="card" style={{ marginBottom: 12 }}>
        <div className="title">跨学科知识图谱智能体</div>
        <div className="controls">
          <input
            type="text"
            value={concept}
            onChange={(e) => setConcept(e.target.value)}
            placeholder="输入概念词，例如 熵 / Entropy / 神经网络"
          />
          <button onClick={onGenerate} disabled={busy || !concept.trim()}>
            Generate
          </button>
          {job && <span className="pill">{job.status}</span>}
          {job && <span className="muted">{job.message || ""}</span>}
        </div>

        {job && (
          <div style={{ marginTop: 10 }}>
            <div className="progress">
              <div style={{ width: `${job.progress}%` }} />
            </div>
          </div>
        )}

        {error && (
          <div style={{ marginTop: 10, color: "#b91c1c" }}>
            <b>Error:</b> {error}
          </div>
        )}
      </div>

      <div className="row">
        <div className="card">
          <div className="title">Graph</div>
          {graph ? (
            <GraphView nodes={graph.nodes} edges={graph.edges} onNodeClick={pickNode} />
          ) : (
            <div className="muted">点击 Generate 后会显示图谱。</div>
          )}
        </div>

        <div className="card">
          <div className="title">Node Detail</div>
          {selectedNode ? (
            <>
              <div className="pill">{selectedNode.domain}</div>
              <div style={{ fontSize: 18, fontWeight: 700, marginTop: 8 }}>{selectedNode.name}</div>
              <div className="kv">
                <div>ID</div>
                <div>{selectedNode.id}</div>
                <div>Confidence</div>
                <div>{selectedNode.confidence.toFixed(2)}</div>
                <div>Definition</div>
                <div>{selectedNode.definition || "-"}</div>
              </div>
              <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
                <button onClick={onExpand} disabled={busy}>
                  Expand (2-hop)
                </button>
              </div>
            </>
          ) : (
            <div className="muted">点击图谱节点查看详情；未通过 Check layer 的边会显示红色虚线。</div>
          )}

          {job?.logs?.length ? (
            <>
              <div className="title" style={{ marginTop: 14 }}>
                Job Logs
              </div>
              <div className="log">{job.logs.slice(-40).join("\n")}</div>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}

