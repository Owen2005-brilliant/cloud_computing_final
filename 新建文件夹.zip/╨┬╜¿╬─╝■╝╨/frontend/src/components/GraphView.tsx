import React from "react";
import ReactECharts from "echarts-for-react";
import type { Edge, Node } from "../api";

const DOMAIN_COLORS: Record<string, string> = {
  Core: "#111827",
  Mathematics: "#2563eb",
  Physics: "#7c3aed",
  "Computer Science": "#059669",
  Biology: "#db2777",
  Economics: "#d97706",
  Bridge: "#0ea5e9"
};

function colorFor(domain: string): string {
  return DOMAIN_COLORS[domain] || "#374151";
}

export function GraphView(props: {
  nodes: Node[];
  edges: Edge[];
  onNodeClick?: (nodeId: string) => void;
}) {
  const option = React.useMemo(() => {
    const data = props.nodes.map((n) => ({
      id: n.id,
      name: n.name,
      value: n.domain,
      symbolSize: 12 + Math.round((n.confidence ?? 0.7) * 18),
      itemStyle: { color: colorFor(n.domain) },
      label: { show: true, formatter: "{b}" }
    }));

    const links = props.edges.map((e) => ({
      source: e.source,
      target: e.target,
      value: e.relation,
      lineStyle: {
        width: 1.6,
        type: e.checked ? "solid" : "dashed",
        color: e.checked ? "#6b7280" : "#ef4444",
        opacity: e.checked ? 0.65 : 0.9
      }
    }));

    const categories = Array.from(new Set(props.nodes.map((n) => n.domain))).map((d) => ({
      name: d,
      itemStyle: { color: colorFor(d) }
    }));

    return {
      tooltip: {
        trigger: "item"
      },
      legend: [{ data: categories.map((c) => c.name) }],
      animationDuration: 300,
      series: [
        {
          type: "graph",
          layout: "force",
          roam: true,
          draggable: true,
          label: { position: "right" },
          force: { repulsion: 120, edgeLength: 80 },
          data,
          links,
          categories,
          emphasis: { focus: "adjacency" }
        }
      ]
    };
  }, [props.nodes, props.edges]);

  return (
    <ReactECharts
      option={option}
      style={{ height: 520, width: "100%" }}
      onEvents={{
        click: (params: any) => {
          if (params?.dataType === "node") {
            props.onNodeClick?.(params.data?.id);
          }
        }
      }}
    />
  );
}

